                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2236737
Region Free Super Famicom Cartridge Back Panel by nebajnim101 is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

This is the back portion to a Super Famicom cartridge. It can be used to create a completely new blank SF cartridge (front portion not included) or it can be used to modify an authentic cartridge as I have done [Pictured]. This panel is region free, in so far as it includes the notches that fit over the corresponding posts seen in the cartridge slot of the US SNES (IE: if you replace an authentic SF cart's back panel with this thing it will allow it to physically fit in the cartridge slot of a standard SNES).

(FYI: If you're using Cura and want usagi_'s design logo and "Nintendo" text to appear you need to print the initial layer at at most 0.2 resolution. Otherwise it just wont show up on the final print.)

# Post-Printing

I purposefully made the holes for the screws too small (1mm), with the expectation that the end user will drill, bore, tap them to fit whatever screws they happen to be using. I personally use a small metal sanding cone with my dremel to widen the holes and just bore the original Super Famicom cart screws in place (I know I should be using a tap, but I don't have one small enough yet), but to each their own.

# How I Designed This

I designed this thing using Tinkercad. I imported the back portion of usagi_'s wonderfully dimensionally accurate Super Famicom cartridge design and made it functional using the guts of CCalo's SNES Cartridge design, while also making a few modifications for strength and compatibility with an authentic SF cart.

-I added the SNES notches like I said.
-I made the center support post an elongated cube as opposed to the original cylinder:  While more accurate to the original designs of both carts the original cylinder seen on CCalo's SNES cart design didn't come out very strong in my case (it snapped off pretty easy), so I replaced it with the aforementioned elongated cube which is much stronger.
-I made the lowermost ledge thicker: It's a bit thin on the original SNES design (it printed like support material on my printer).
-I brought the screw holes down 2mm to meet the holes on a standard SF cart front portion.
-I added receiving holes to the top edge to fit the clips seen on authentic SF carts.
-I made the screw holes smaller [See Post-Printing] and taller.